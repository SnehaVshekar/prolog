% goal predicate will take the form:
% queens (N, Qs).
% where N = the number of queens
% Qs = solution to the problem

n_queens(N, Qs) :-  
  range(1, N, Ns), 
  n_queens(Ns, [], Qs).

% To generate list of N numbered list[number of queens in chess board N*N]

range(N, N, [N]) :- !.		% Base Case : when reaches N , cuts from this fuction.	

range(M, N, [M|Ns]) :- 		
  M < N, 
  M1 is M+1, 
  range(M1, N, Ns).

n_queens([], Qs, Qs).		% base case

n_queens(UnplacedQs, SafeQs, Qs) :- 
  select(UnplacedQs, UnplacedQs1,Q),
  chck_not_attacked(SafeQs, Q),  
  n_queens(UnplacedQs1, [Q|SafeQs], Qs).  


% checks if the queen is safe by checking its not attacked 
% by other queen diagonally or any rows or columns.

chck_not_attacked(As, A) :- chck_not_attacked(As, A, 1).
chck_not_attacked([], _, _) :- !.	% base case  
chck_not_attacked([B|Bs], A, N) :-	% to check if the the queen is not attacked by any other queen 
						% which is already placed on the chess board.
  A =\= B+N,  
  A =\= B-N, 
  N1 is N+1, 
  chck_not_attacked(Bs, A, N1).

select([A|As], As, A).			% selects and deletes from the list
select([B|Bs], [B|Cs], A) :- select(Bs, Cs, A).
