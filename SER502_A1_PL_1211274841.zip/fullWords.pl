% Converting numbers to words.
% Sample run 
% ?- full_words(283).
% two-eight-three

 % numbers with respective words are written.

num(0) :- write('zero').
num(1) :- write('one').
num(2) :- write('two').
num(3) :- write('three').
num(4) :- write('four').
num(5) :- write('five').
num(6) :- write('six').
num(7) :- write('seven').
num(8) :- write('eight').
num(9) :- write('nine').

full_words(Nums) :-       	% This is top-level predicate.
    NDiv is Nums // 10,  	%  prints the first digit unconditionally,
    num_words(NDiv),		% lets you handle the case when the number is zero.
    NMod is Nums mod 10, 
    num(NMod).

num_words(0).      	 % When we reach zero, we stop printing.

num_words(Nums) :- 	 % Otherwise, we follow this algorithm
    Nums > 0,           		 % with one modification- the dash is printed
    NDiv is Nums // 10,  	% unconditionally before printing the digit.
    num_words(NDiv),	% recursive call
    NMod is Nums mod 10,
    num(NMod),
    write('-').		% writes hyphen after each number written in words.


