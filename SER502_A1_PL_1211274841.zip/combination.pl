% Generate the combinations of K distinct objects chosen from the N elements of a list:
% Sample run :
% ?- combination(3,[a,b,c,d,e,f],L).
% L = [a,b,c] ;
% L = [a,b,d] ;
% L = [a,b,e] ;
% ......

% combination(No_of_ways, List_of_numbers/chars , L-o/p of_lists_of_possible_combinations). 

combination(1, [H|_], [H]).
combination(N, [H|T], [H|Com]) :-
 integer(N), N1 is N - 1, 			% checks if it is an integer and reduces N by 1.
 N1 > 0,					% checks if N1 is greater than 0.
 combination(N1, T, Com).			
	
% recursively calls top level predicate to find different combinations.

combination(N, [_|T], Com) :- combination(N, T, Com).
