% File Name: findpath.pl
% findpath(X,Y,Weight,Path).
% where X, Y = name of the node
% Weight = weight of the path taken
% Path = path taken in the form of a list

% Sample run
% ?- findpath(a,e,Weight,Path).
% Path = [a,b,e]
% Weight = 2;
% ......
% Path = [a,c,d,e]
% Weight = 8 ;
% ......

% defining edges in a graph along with weight associated with the edge.

edge(a,b,1).
edge(a,c,6).
edge(b,c,4).
edge(b,d,3).
edge(c,d,1).
edge(d,e,1).
edge(e,b,1).


% To represent that the edges are bi-directional.
connected(X,Y,W) :- edge(X,Y,W) ; edge(Y,X,W).
% A- Source , B- Destination node
% Path- path from src node to destination node
% Weight - Weight of the edges traversed

findpath(Src_Vertex,Dest_Vertex,Weight,Path) :- travel_graph(Src_Vertex,Dest_Vertex,[Src_Vertex],Q,Weight),
    reverse(Q,Path).

travel_graph(Src_Vertex,Dest_Vertex,P,[Dest_Vertex|P],Weight) :- connected(Src_Vertex,Dest_Vertex,Weight).

% starting from source vertex, visits each node and then visited nodes are stored in a list so that it doesn't have cycles.
% if the vertex is a member of the visited list then that path is not considered.
  
travel_graph(Src_Vertex,Dest_Vertex,Visited,Path,Weight) :- connected(Src_Vertex,C,W1),
	C \==Dest_Vertex,
	\+member(C,Visited),
	travel_graph(C,Dest_Vertex,[C|Visited],Path,W2),
	Weight is W1 + W2.

