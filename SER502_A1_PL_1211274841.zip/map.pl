% color_map1(LIST_MAP_NO, LIST_OF_COLORS, COLORING_LIST) takes a list of area names/numbers associated with the areas/MAP and list of
% colors , and returns COLORING to be a list of pairs [AREA, COLOR], where every area is assigned a color, and no
% adjacent areas are assigned the same color.

adjacent(1,2). 
adjacent(1,3). 
adjacent(1,4).  
adjacent(1,6). 
adjacent(2,3).  
adjacent(2,5).  
adjacent(3,4). 
adjacent(3,5). 
adjacent(3,6). 
adjacent(4,5). 
adjacent(4,6).

% checks for adjacency.

adjacent1(X,Y) :-adjacent(X,Y).
adjacent1(X,Y) :-adjacent(Y,X).

% Top level predicate.

color_map(L):-color_map1([1,2,3,4,5,6],[red,blue,green,yellow], L).

% base case : if the map list is empty then no coloring is done.

color_map1([],_, []).	

% Recursive case: color the tail of the MAP, then add a color for the head
% in a way that does not conflict.

color_map1([HEAD | TAIL], COLORS, [[HEAD, HCOLOR] | TAIL_COLORING]) :-
  color_map1(TAIL, COLORS, TAIL_COLORING),
  member(HCOLOR, COLORS),
 \+conflicts(HEAD, HCOLOR, TAIL_COLORING).	% checks if there is conflict in   coloring the adjacent sides.

conflicts(AREA1, COLOR, [[AREA2, COLOR] | _]) :-
   adjacent1(AREA1, AREA2).

% Recursive case: continue to search down the list COLORING.
conflicts(AREA, COLOR, [_|COLORING]) :-
   conflicts(AREA, COLOR, COLORING).

% member as usual

member(X,[X|_]).
member(X,[_|TAIL]) :- member(X,TAIL).

