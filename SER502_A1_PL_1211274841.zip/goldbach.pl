% prime number should not be an even number
% it shuld not have factors other than 1 and itself
% Goldbach = Every even integer greater than 2 can be expressed as the sum of two primes.

is_prime(2).							% declaring 2 as prime no.
is_prime(N) :- integer(N), N mod 2 =\= 0, \+ has_factor(N,3).

has_factor(N,L) :- N mod L =:= 0.
has_factor(N,L) :- L * L < N, L1 is L + 2, has_factor(N,L1).			% checks if the number has a factor!
% case if even number is 4, then 4= 2+2.
goldbach(4,[2,2]) :- !.	
% checks if N(i/p) is even number, N >4 , calls goldbach(even_no,List,3(prime_no)).
goldbach(N,L) :- integer(N), N mod 2 =:= 0, N > 4, goldbach(N,L,3).		
goldbach(N,[P,Q],P) :- Q is N - P, is_prime(Q), Q>1.					
% Q is another no after subtracting 3 from N. If Q obtained is prime_no then other choices are discarded.
goldbach(N,L,P) :- P < N, gen_next_prime(P,P1), goldbach(N,L,P1).

gen_next_prime(P,P1) :- P1 is P + 2, is_prime(P1), !.						
% To generated next set of prime numbers. Begins by adding 2 to the number obtained.
gen_next_prime(P,P1) :- P2 is P + 2, gen_next_prime(P2,P1).
