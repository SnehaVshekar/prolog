% Tower of hanoi
% hanoi( no_of_disks , src, dest, temp )
hanoi(1,Source,Destination,_):-write('Move disk from '),write(Source),write(' to '),write(Destination),nl.
% for each recursive call, No of disks are reduced by 1 which is equal to M.
% recursively moves the disk from source to destination using a temporary tower.
hanoi(No_of_disks,Source,Destination,Temp):-No_of_disks>1,M is No_of_disks-1,		 
	hanoi(M,Source,Temp,Destination),             
  	hanoi(1,Source,Destination,_), 	 
  	hanoi(M,Temp,Destination,Source).
